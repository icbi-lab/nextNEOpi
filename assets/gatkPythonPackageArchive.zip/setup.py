from setuptools import setup, find_packages

setup(name='gatkpythonpackages',
      version='0.1',
      description='GATK python packages',
      author='GATK Team',
      packages=find_packages(),
      zip_safe=False)

